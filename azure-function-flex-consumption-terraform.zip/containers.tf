# Optional application containers for this Function-specific storage account.
# These are private and are separate from the project's main application
# Storage Account containers.

resource "azurerm_storage_container" "raw_lab_reports" {
  name                  = "raw-lab-reports"
  storage_account_id    = azurerm_storage_account.function.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "raw_vitals" {
  name                  = "raw-vitals"
  storage_account_id    = azurerm_storage_account.function.id
  container_access_type = "private"
}

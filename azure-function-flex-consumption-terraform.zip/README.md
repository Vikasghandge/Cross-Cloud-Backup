# Azure Function - Flex Consumption Terraform

This configuration creates ONLY the Azure Function infrastructure.

## Creates

1. Function runtime Storage Account
2. Private `function-app-package` blob container
3. Optional private `raw-lab-reports` container
4. Optional private `raw-vitals` container
5. Linux Flex Consumption Service Plan (`FC1`)
6. Linux Azure Function App using Python 3.11
7. System-assigned Managed Identity

## Existing project resources used

Resource Group:
`GenAI-B5-Project-T5-RG`

Region:
`Central US`

## Intentionally NOT created here

- VNet
- Subnets
- VNet Integration
- Private Endpoints
- Private DNS
- Event Grid
- Blob triggers
- Function Python source code
- Existing application Storage Account
- Document Intelligence
- Azure OpenAI
- PostgreSQL
- Key Vault
- Application Insights

Networking and event configuration can be completed manually as requested.

## Important storage distinction

The Function App needs its own runtime/package storage configuration.

Your project's main application Storage Account remains separate:

- `lab-reports`
- `processed-data`
- `progress-notes`

Do not replace that existing application Storage Account with this Function runtime Storage Account unless that is an intentional architecture change.

## Terraform commands

```bash
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply
```

After infrastructure creation, deploy the Function code separately.

## Flex Consumption

This configuration uses:

```hcl
sku_name = "FC1"
```

and:

```hcl
resource "azurerm_function_app_flex_consumption" "function"
```

which are the AzureRM Terraform resources for Flex Consumption.

Before applying, replace the example values in `terraform.tfvars.example` with your actual values and save it as `terraform.tfvars`.

# -------------------------------------------------------------------
# Function App runtime Storage Account
# This is the storage used by the Azure Functions runtime/package.
# It is NOT the existing application Storage Account containing:
# lab-reports, processed-data, progress-notes.
# -------------------------------------------------------------------
resource "azurerm_storage_account" "function" {
  name                     = var.function_storage_account_name
  resource_group_name      = var.resource_group_name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  min_tls_version                  = "TLS1_2"
  allow_nested_items_to_be_public  = false
  public_network_access_enabled    = true
}

# Flex Consumption requires a blob container for the Function App
# deployment/package storage.
resource "azurerm_storage_container" "function_package" {
  name                  = var.function_storage_container_name
  storage_account_id    = azurerm_storage_account.function.id
  container_access_type = "private"
}

# -------------------------------------------------------------------
# Flex Consumption Service Plan
# FC1 = Flex Consumption
# -------------------------------------------------------------------
resource "azurerm_service_plan" "function" {
  name                = var.service_plan_name
  resource_group_name = var.resource_group_name
  location            = var.location

  os_type  = "Linux"
  sku_name = "FC1"
}

# -------------------------------------------------------------------
# Azure Function App - Flex Consumption
# Infrastructure only. Function code/triggers are deployed separately.
# -------------------------------------------------------------------
resource "azurerm_function_app_flex_consumption" "function" {
  name                = var.function_app_name
  resource_group_name = var.resource_group_name
  location            = var.location

  service_plan_id = azurerm_service_plan.function.id

  storage_container_type      = "blobContainer"
  storage_container_endpoint  = "${azurerm_storage_account.function.primary_blob_endpoint}${azurerm_storage_container.function_package.name}"
  storage_authentication_type = "StorageAccountConnectionString"
  storage_access_key          = azurerm_storage_account.function.primary_access_key

  runtime_name    = "python"
  runtime_version = "3.11"

  maximum_instance_count = var.maximum_instance_count
  instance_memory_in_mb  = var.instance_memory_in_mb

  https_only = true

  identity {
    type = "SystemAssigned"
  }

  site_config {}
}

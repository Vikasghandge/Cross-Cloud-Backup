output "function_app_name" {
  value = azurerm_function_app_flex_consumption.function.name
}

output "function_app_hostname" {
  value = azurerm_function_app_flex_consumption.function.default_hostname
}

output "function_service_plan_id" {
  value = azurerm_service_plan.function.id
}

output "function_storage_account_name" {
  value = azurerm_storage_account.function.name
}

output "function_package_container_name" {
  value = azurerm_storage_container.function_package.name
}

output "managed_identity_principal_id" {
  value = azurerm_function_app_flex_consumption.function.identity[0].principal_id
}

variable "subscription_id" {
  description = "Azure subscription ID"
  type        = string
}

variable "resource_group_name" {
  description = "Existing resource group"
  type        = string
  default     = "GenAI-B5-Project-T5-RG"
}

variable "location" {
  description = "Azure region"
  type        = string
  default     = "Central US"
}

variable "function_app_name" {
  description = "Globally unique Azure Function App name. Keep <= 32 characters."
  type        = string
}

variable "function_storage_account_name" {
  description = "Globally unique storage account name, 3-24 lowercase characters."
  type        = string
}

variable "function_storage_container_name" {
  description = "Blob container used by the Flex Consumption Function App runtime."
  type        = string
  default     = "function-app-package"
}

variable "service_plan_name" {
  description = "Flex Consumption service plan name"
  type        = string
  default     = "asp-healthcare-function-flex"
}

variable "maximum_instance_count" {
  description = "Maximum number of Flex Consumption instances."
  type        = number
  default     = 50
}

variable "instance_memory_in_mb" {
  description = "Memory per Flex Consumption instance."
  type        = number
  default     = 2048
}

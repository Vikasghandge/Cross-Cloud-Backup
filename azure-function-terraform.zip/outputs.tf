output "function_app_name" {
  value = azurerm_linux_function_app.function.name
}

output "function_app_hostname" {
  value = azurerm_linux_function_app.function.default_hostname
}

output "function_storage_account_name" {
  value = azurerm_storage_account.function.name
}

output "managed_identity_principal_id" {
  value = azurerm_linux_function_app.function.identity[0].principal_id
}

# Azure Function Terraform

Creates only the Azure Function infrastructure.

Creates:
- Function runtime Storage Account
- Linux App Service Plan (Y1 Consumption)
- Linux Function App
- System-assigned Managed Identity
- Python 3.11 runtime

Does NOT create:
- VNet/subnets
- VNet Integration
- Event Grid/triggers
- Function code
- Application Storage Account
- Private Endpoints
- Private DNS

Existing Resource Group:
GenAI-B5-Project-T5-RG
Region:
Central US

Run:
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply

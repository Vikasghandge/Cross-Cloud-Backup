variable "subscription_id" {
  type = string
}

variable "resource_group_name" {
  type    = string
  default = "GenAI-B5-Project-T5-RG"
}

variable "location" {
  type    = string
  default = "Central US"
}

variable "function_app_name" {
  type = string
}

variable "function_storage_account_name" {
  type = string
}

variable "service_plan_name" {
  type    = string
  default = "asp-healthcare-function"
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "openai_name" {
  type        = string
  description = "Globally unique Azure OpenAI account name"
}

variable "vnet_id" {
  type        = string
  description = "Existing VNet resource ID"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Existing Private Endpoint subnet resource ID (10.0.2.0/24)"
}

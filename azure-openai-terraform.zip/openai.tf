# Azure OpenAI account
resource "azurerm_cognitive_account" "openai" {
  name                  = var.openai_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  kind                  = "OpenAI"
  sku_name              = "S0"
  custom_subdomain_name = var.openai_name

  public_network_access_enabled = false

  tags = {
    environment = "demo"
    purpose     = "progress-notes-generation"
  }
}

# Private DNS zone for Azure OpenAI / Cognitive Services
resource "azurerm_private_dns_zone" "openai" {
  name                = "privatelink.openai.azure.com"
  resource_group_name = var.resource_group_name
}

# Link DNS zone to existing VNet
resource "azurerm_private_dns_zone_virtual_network_link" "openai" {
  name                  = "openai-dns-vnet-link"
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.openai.name
  virtual_network_id    = var.vnet_id
}

# Private Endpoint in existing Private Endpoint subnet
resource "azurerm_private_endpoint" "openai" {
  name                = "openai-private-endpoint"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id

  private_service_connection {
    name                           = "openai-private-connection"
    private_connection_resource_id = azurerm_cognitive_account.openai.id
    is_manual_connection           = false
    subresource_names              = ["account"]
  }

  private_dns_zone_group {
    name = "openai-dns-zone-group"

    private_dns_zone_ids = [
      azurerm_private_dns_zone.openai.id
    ]
  }
}

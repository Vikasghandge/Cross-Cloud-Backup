# Azure OpenAI + Private Endpoint - Terraform

Creates:

1. Azure OpenAI resource
2. Private DNS Zone:
   `privatelink.openai.azure.com`
3. Private DNS Zone -> existing VNet link
4. Private Endpoint in the EXISTING Private Endpoint subnet (`10.0.2.0/24`)

No new VNet or subnet is created.

Architecture:

Backend / Function
       |
       | VNet Integration
       v
App Service Integration Subnet
10.0.1.0/24
       |
       v
Private Endpoint
10.0.2.0/24
       |
       v
Azure OpenAI

IMPORTANT:
This creates the Azure OpenAI account and private connectivity.
It does NOT deploy an OpenAI model/deployment yet.

Azure OpenAI resource creation may require an Azure subscription/resource
provider quota or organization permission. If Terraform returns a
permission/quota/policy error, do not bypass it; share the error and we
can adjust the next step.

Run:

terraform init
terraform fmt
terraform validate
terraform plan
terraform apply

Always review `terraform plan` before applying.

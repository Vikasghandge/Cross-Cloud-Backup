output "openai_id" {
  value = azurerm_cognitive_account.openai.id
}

output "openai_endpoint" {
  value = azurerm_cognitive_account.openai.endpoint
}

output "private_endpoint_id" {
  value = azurerm_private_endpoint.openai.id
}

output "private_endpoint_ip" {
  value = azurerm_private_endpoint.openai.private_service_connection[0].private_ip_address
}

output "private_dns_zone" {
  value = azurerm_private_dns_zone.openai.name
}
